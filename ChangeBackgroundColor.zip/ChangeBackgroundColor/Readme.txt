ProjectName: Background Color changing using JS

Description: This background changing project will help user to change the color of the background. A button will be displayed at the center , clicking on which the background color will change.

Solution approach: 

1. HTML file: Giving a meaningful heading and a button at the center.
2. CSS file: To style the basic HTML, however you want.
3. JS file: Creating a function that takes the id of body. Craetes an array of different color. Parse through the array, and return a random color whenever the button is clicked.
